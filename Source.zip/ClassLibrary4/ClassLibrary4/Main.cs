﻿using MelonLoader;
using Steamworks;
using UnityEngine;
using System.Collections.Generic;

[assembly: MelonInfo(typeof(Kuromi.ServerBrowser), "SAM", "1.0.0", "List")]
[assembly: MelonGame(null, null)]

namespace Kuromi
{
    public class ServerBrowser : MelonMod
    {
        private bool menuOpen = true;
        private Rect windowRect = new Rect(100, 100, 600, 450);
        private Vector2 scroll = Vector2.zero;
        private int currentTab = 0;
        private string[] tabs = new string[] { "Browse", "Host", "Players" };

        private List<CSteamID> lobbies = new List<CSteamID>();
        private string serverName = "Loading...";
        private bool hosting = false;
        private bool inLobby = false;
        private CSteamID currentLobby;

        private const double version = 2.0;
        private bool updateRequired = false;
        private string updateMessage = "";
        private bool UpdateChecked = false;

        private Callback<LobbyMatchList_t> lobbyListCallback;
        private Callback<LobbyCreated_t> lobbyCreatedCallback;
        private Callback<LobbyEnter_t> lobbyEnterCallback;

        private float nextLobbyRefresh = 0f;

        public override void OnInitializeMelon()
        {
            lobbyListCallback = Callback<LobbyMatchList_t>.Create(OnLobbyListReceived);
            lobbyCreatedCallback = Callback<LobbyCreated_t>.Create(OnLobbyCreated);
            lobbyEnterCallback = Callback<LobbyEnter_t>.Create(OnLobbyEntered);

            try
            {
                serverName = SteamFriends.GetPersonaName() + "'s Room";
            }
            catch
            {
                serverName = "Player's Room";
            }
        }

        public override void OnUpdate()
        {

            if (!UpdateChecked)
            {
                UpdateChecked = true;

                MelonCoroutines.Start(CheckVersion());
            }

            if (Input.GetKeyDown(KeyCode.P))
                menuOpen = !menuOpen;

            if (Time.realtimeSinceStartup > nextLobbyRefresh)
            {
                nextLobbyRefresh = Time.realtimeSinceStartup + 5f;
                if (menuOpen && currentTab == 0 && !hosting)
                    RefreshLobbyList();
            }
        }

        public override void OnGUI()
        {
            if (updateRequired)
            {
                Color overlay = new Color(0, 0, 0, 0.8f);
                GUI.color = overlay;
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
                GUI.color = Color.white;

                float boxWidth = 480f;
                float boxHeight = 240f;
                float centerX = (Screen.width - boxWidth) / 2f;
                float centerY = (Screen.height - boxHeight) / 2f;

                Rect boxRect = new Rect(centerX, centerY, boxWidth, boxHeight);
                GUIStyle boxStyle = new GUIStyle(GUI.skin.box);
                boxStyle.alignment = TextAnchor.MiddleCenter;
                boxStyle.fontSize = 18;
                boxStyle.normal.textColor = Color.white;
                boxStyle.wordWrap = true;

                GUI.Box(boxRect, "", boxStyle);

                GUIStyle titleStyle = new GUIStyle(GUI.skin.label);
                titleStyle.alignment = TextAnchor.MiddleCenter;
                titleStyle.fontSize = 26;
                titleStyle.fontStyle = FontStyle.Bold;
                titleStyle.normal.textColor = new Color(1f, 0.3f, 0.7f);

                GUI.Label(new Rect(0, centerY + 15, Screen.width, 40), "Update Required (SAM Broswer)", titleStyle);

                GUIStyle msgStyle = new GUIStyle(GUI.skin.label);
                msgStyle.alignment = TextAnchor.MiddleCenter;
                msgStyle.fontSize = 16;
                msgStyle.wordWrap = true;
                msgStyle.normal.textColor = Color.white;

                GUI.Label(
                    new Rect(centerX + 20, centerY + 65, boxWidth - 40, 80),
                    updateMessage + "\n\nA new version is available.\nPlease update to continue using the mod.",
                    msgStyle
                );

                GUIStyle buttonStyle = new GUIStyle(GUI.skin.button);
                buttonStyle.fontSize = 18;
                buttonStyle.fontStyle = FontStyle.Bold;
                buttonStyle.normal.textColor = Color.white;

                if (GUI.Button(new Rect(centerX + (boxWidth / 2f) - 100, centerY + boxHeight - 60, 200, 40),
                    "Open GitHub", buttonStyle))
                {
                    Application.OpenURL("https://github.com/kitty92pm/Shift-At-Midnight-Server-broswer/releases/tag/Beta");
                }

                return; // block rest of UI
            }


            if (!menuOpen) return;
            windowRect = GUI.Window(1234, windowRect, DrawWindow,
                "Shift - At - Midnight | Server Browser (P to open and close)");
        }


        private void DrawWindow(int id)
        {
            GUILayout.BeginVertical();

            GUILayout.BeginHorizontal();
            for (int i = 0; i < tabs.Length; i++)
            {
                GUI.color = (i == currentTab) ? Color.magenta : Color.white;
                if (GUILayout.Button(tabs[i], GUILayout.Height(28)))
                    currentTab = i;
            }
            GUI.color = Color.white;
            GUILayout.EndHorizontal();

            GUILayout.Space(10);

            if (currentTab == 0) DrawBrowseTab();
            else if (currentTab == 1) DrawHostTab();
            else if (currentTab == 2) DrawPlayersTab();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private void DrawBrowseTab()
        {
            if (GUILayout.Button("Refresh Lobbies", GUILayout.Height(30)))
                RefreshLobbyList();

            scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(300));
            foreach (CSteamID lobby in lobbies)
            {
                string name = SteamMatchmaking.GetLobbyData(lobby, "name");
                string host = SteamMatchmaking.GetLobbyData(lobby, "host");
                if (string.IsNullOrEmpty(name)) name = "Unnamed Lobby";
                if (string.IsNullOrEmpty(host)) host = "Unknown Host";

                GUILayout.BeginHorizontal(GUI.skin.box);
                GUILayout.Label(name + " — Host: " + host, GUILayout.Width(380));
                if (GUILayout.Button("Join", GUILayout.Width(100)))
                {
                    SteamMatchmaking.JoinLobby(lobby);
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
        }

        private void DrawHostTab()
        {
            if (!hosting && !inLobby)
            {
                GUILayout.Label("Create Public Lobby", GUI.skin.box);
                GUILayout.Space(5);
                GUILayout.Label("Lobby Name:");
                serverName = GUILayout.TextField(serverName, GUILayout.Width(300));

                if (GUILayout.Button("Host", GUILayout.Height(30)))
                    HostLobby();
            }
            else
            {
                GUILayout.Label("Hosting: " + serverName, GUI.skin.box);
                if (GUILayout.Button("Stop Hosting", GUILayout.Height(30)))
                    LeaveCurrentLobby();
            }
        }

        private void DrawPlayersTab()
        {
            if (!inLobby && !hosting)
            {
                GUILayout.Label("Not in a lobby.");
                return;
            }

            GUILayout.Label("Players in Lobby:", GUI.skin.box);

            int count = SteamMatchmaking.GetNumLobbyMembers(currentLobby);
            for (int i = 0; i < count; i++)
            {
                CSteamID mem = SteamMatchmaking.GetLobbyMemberByIndex(currentLobby, i);
                string name = SteamFriends.GetFriendPersonaName(mem);
                GUILayout.Label(name);
            }

            GUILayout.Space(10);

            if (hosting)
            {
                if (GUILayout.Button("Stop Hosting", GUILayout.Height(30)))
                    LeaveCurrentLobby();
            }
            else
            {
                GUILayout.Label("Clients cannot leave; exit through the game.", GUI.skin.box);
            }
        }


        private void HostLobby()
        {
            SteamMatchmaking.CreateLobby(ELobbyType.k_ELobbyTypePublic, 8);
        }

        private void RefreshLobbyList()
        {
            lobbies.Clear();
            SteamMatchmaking.RequestLobbyList();
        }

        private void OnLobbyListReceived(LobbyMatchList_t result)
        {
            lobbies.Clear();
            for (int i = 0; i < result.m_nLobbiesMatching; i++)
            {
                CSteamID lid = SteamMatchmaking.GetLobbyByIndex(i);
                lobbies.Add(lid);
            }
            MelonLogger.Msg("Lobbies found: " + lobbies.Count);
        }

        private void OnLobbyCreated(LobbyCreated_t callback)
        {
            if (callback.m_eResult != EResult.k_EResultOK)
            {
                MelonLogger.Error("Failed to create lobby: " + callback.m_eResult);
                return;
            }

            currentLobby = new CSteamID(callback.m_ulSteamIDLobby);
            SteamMatchmaking.SetLobbyType(currentLobby, ELobbyType.k_ELobbyTypePublic);
            SteamMatchmaking.SetLobbyData(currentLobby, "name", serverName);
            SteamMatchmaking.SetLobbyData(currentLobby, "host", SteamFriends.GetPersonaName());
            hosting = true;
            inLobby = true;
            MelonLogger.Msg("Lobby created: " + serverName);
        }

        private void OnLobbyEntered(LobbyEnter_t callback)
        {
            currentLobby = new CSteamID(callback.m_ulSteamIDLobby);
            inLobby = true;

            CSteamID owner = SteamMatchmaking.GetLobbyOwner(currentLobby);
            hosting = (owner == SteamUser.GetSteamID());

            MelonLogger.Msg("Joined lobby: " + currentLobby + " | Hosting: " + hosting);
        }

        private void LeaveCurrentLobby()
        {
            if (hosting)
            {
                SteamMatchmaking.LeaveLobby(currentLobby);
                MelonLogger.Msg("Host stopped hosting and left the lobby.");
            }
            else
            {
                MelonLogger.Msg("Client attempted to leave but is restricted. Must exit game.");
                return;
            }

            hosting = false;
            inLobby = false;
            lobbies.Clear();
        }

        private System.Collections.IEnumerator CheckVersion()
        {
            yield return new WaitForSeconds(3f);

            string url = "https://raw.githubusercontent.com/kitty92pm/Shift-At-Midnight-Server-broswer/main/version.txt";
            using (var req = UnityEngine.Networking.UnityWebRequest.Get(url))
            {
                req.downloadHandler = new UnityEngine.Networking.DownloadHandlerBuffer();
                var op = req.SendWebRequest();

                while (!op.isDone)
                    yield return null;

                bool success = (req.result != UnityEngine.Networking.UnityWebRequest.Result.ConnectionError &&
                                req.result != UnityEngine.Networking.UnityWebRequest.Result.ProtocolError);

                if (success)
                {
                    string text = req.downloadHandler.text.Trim();
                    MelonLogger.Msg("[VersionCheck] Remote text: " + text);

                    if (double.TryParse(text, System.Globalization.NumberStyles.Float,
                                        System.Globalization.CultureInfo.InvariantCulture, out double onlineVersion))
                    {
                        if (onlineVersion > version)
                        {
                            updateRequired = true;
                            updateMessage = $"Update required! Current: {version} | Latest: {onlineVersion}";
                            MelonLogger.Warning(updateMessage);
                        }
                        else
                            MelonLogger.Msg($"[VersionCheck] Version OK ({version})");
                    }
                    else
                    {
                        MelonLogger.Error("[VersionCheck] Invalid file content: " + text);
                    }
                }
                else
                {
                    MelonLogger.Error("[VersionCheck] Web error: " + req.error + " | Result: " + req.result);
                }
            }
        }
    }
}