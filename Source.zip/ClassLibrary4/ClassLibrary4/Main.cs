﻿using MelonLoader;
using Steamworks;
using UnityEngine;
using System.Collections.Generic;

[assembly: MelonInfo(typeof(Kuromi.ServerBrowser), "SAM", "1.0.0", "List")]
[assembly: MelonGame(null, null)]

namespace Kuromi
{
    public class ServerBrowser : MelonMod
    {
        private bool menuOpen = true;
        private Rect windowRect = new Rect(100, 100, 620, 470);
        private Vector2 scroll = Vector2.zero;
        private int currentTab = 0;
        private string[] tabs = new string[] { "Browse", "Host", "Players"};

        private List<CSteamID> lobbies = new List<CSteamID>();
        private string serverName = "My Server";
        private bool hosting = false;
        private bool inLobby = false;
        private CSteamID currentLobby;

        private const double version = 4.0;
        private bool updateRequired = false;
        private string updateMessage = "";
        private bool UpdateChecked = false;

        private float menuAlpha = 1f;
        private float fadeSpeed = 5f;
        private bool refreshing = false;
        private string footerStatus = "Idle";

        private Callback<LobbyMatchList_t> lobbyListCallback;
        private Callback<LobbyCreated_t> lobbyCreatedCallback;
        private Callback<LobbyEnter_t> lobbyEnterCallback;

        private float nextLobbyRefresh = 0f;

        public override void OnInitializeMelon()
        {
            lobbyListCallback = Callback<LobbyMatchList_t>.Create(OnLobbyListReceived);
            lobbyCreatedCallback = Callback<LobbyCreated_t>.Create(OnLobbyCreated);
            lobbyEnterCallback = Callback<LobbyEnter_t>.Create(OnLobbyEntered);

            currentTab = PlayerPrefs.GetInt("SAM_LastTab", 0);
            serverName = PlayerPrefs.GetString("My Server");
        }

        public override void OnUpdate()
        {
            float target = menuOpen ? 1f : 0f;
            menuAlpha = Mathf.Lerp(menuAlpha, target, Time.deltaTime * fadeSpeed);

            if (!UpdateChecked)
            {
                UpdateChecked = true;
                MelonCoroutines.Start(CheckVersion());
            }

            if (Input.GetKeyDown(KeyCode.P))
                menuOpen = !menuOpen;

            if (Time.realtimeSinceStartup > nextLobbyRefresh)
            {
                nextLobbyRefresh = Time.realtimeSinceStartup + 5f;
                if (menuOpen && currentTab == 0 && !hosting)
                    RefreshLobbyList();
            }
        }

        public override void OnApplicationQuit()
        {
            PlayerPrefs.SetInt("SAM_LastTab", currentTab);
            PlayerPrefs.SetString("SAM_LastName", serverName);
            PlayerPrefs.Save();
        }

        public override void OnGUI()
        {
            KuromiNotify.Draw();

            if (updateRequired)
            {
                DrawUpdateOverlay();
                return;
            }

            if (menuAlpha > 0.05f)
            {
                GUI.color = new Color(1f, 1f, 1f, menuAlpha);
                windowRect = GUI.Window(1234, windowRect, DrawWindow,
                    "Shift - At - Midnight | Server Browser (P to open/close)");
                GUI.color = Color.white;
            }
        }

        private void DrawWindow(int id)
        {
            GUILayout.BeginVertical();

            // Tabs
            GUILayout.BeginHorizontal();
            for (int i = 0; i < tabs.Length; i++)
            {
                GUI.color = (i == currentTab) ? Color.magenta : Color.white;
                if (GUILayout.Button(tabs[i], GUILayout.Height(28))) currentTab = i;
            }
            GUI.color = Color.white;
            GUILayout.EndHorizontal();

            GUILayout.Space(8);

            // Tabs content
            if (currentTab == 0) DrawBrowseTab();
            else if (currentTab == 1) DrawHostTab();
            else DrawPlayersTab();

            GUILayout.Space(5);
            DrawFooter();

            GUILayout.EndVertical();
            GUI.DragWindow();
        }

        private void DrawFooter()
        {
            GUILayout.FlexibleSpace();
            GUILayout.BeginHorizontal(GUI.skin.box);
            GUILayout.Label($"Status: {footerStatus}  |  Lobbies: {lobbies.Count}  |  User: {SteamFriends.GetPersonaName()}",
                GUILayout.Height(20));
            GUILayout.EndHorizontal();
        }

        private void DrawBrowseTab()
        {
            if (GUILayout.Button("Refresh Lobbies", GUILayout.Height(30)))
                RefreshLobbyList();

            if (refreshing)
            {
                GUILayout.Label("Refreshing Lobbies...", GUI.skin.label);
            }

            scroll = GUILayout.BeginScrollView(scroll, GUILayout.Height(300));
            foreach (CSteamID lobby in lobbies)
            {
                string name = SteamMatchmaking.GetLobbyData(lobby, "name");
                string host = SteamMatchmaking.GetLobbyData(lobby, "host");
                int count = SteamMatchmaking.GetNumLobbyMembers(lobby);

                if (string.IsNullOrEmpty(name)) name = "Unnamed Lobby";
                if (string.IsNullOrEmpty(host)) host = "Unknown Host";

                bool isFriend = false;
                try { isFriend = SteamFriends.HasFriend(SteamMatchmaking.GetLobbyOwner(lobby), EFriendFlags.k_EFriendFlagImmediate); }
                catch { }

                GUI.color = isFriend ? Color.cyan : Color.magenta;

                GUILayout.BeginHorizontal(GUI.skin.box);
                GUILayout.Label($"[{count}/3] {name} — Host: {host}", GUILayout.Width(420));
                GUI.color = Color.white;

                if (GUILayout.Button("Join", GUILayout.Width(100)))
                {
                    footerStatus = "Joining " + name + "...";
                    KuromiNotify.Info("Joining lobby: " + name);
                    SteamMatchmaking.JoinLobby(lobby);
                }
                GUILayout.EndHorizontal();
            }
            GUILayout.EndScrollView();
        }

        private void DrawHostTab()
        {
            if (!hosting && !inLobby)
            {
                GUILayout.Label("Create Public Lobby", GUI.skin.box);
                GUILayout.Label("Lobby Name:");
                serverName = GUILayout.TextField(serverName, GUILayout.Width(300));

                if (GUILayout.Button("Host", GUILayout.Height(30)))
                    HostLobby();
            }
            else
            {
                GUILayout.Label("Hosting: " + serverName, GUI.skin.box);
                if (GUILayout.Button("Stop Hosting", GUILayout.Height(30)))
                    LeaveCurrentLobby();
            }
        }

        private void DrawPlayersTab()
        {
            if (!inLobby && !hosting)
            {
                GUILayout.Label("Not in a lobby.");
                return;
            }

            GUILayout.Label("Players in Lobby:", GUI.skin.box);

            int count = SteamMatchmaking.GetNumLobbyMembers(currentLobby);
            for (int i = 0; i < count; i++)
            {
                CSteamID mem = SteamMatchmaking.GetLobbyMemberByIndex(currentLobby, i);
                string name = SteamFriends.GetFriendPersonaName(mem);

                GUILayout.Space(4f);
                GUILayout.Label("User: " + name, GUI.skin.box);
            }

            /*
            GUILayout.Space(10);

            if (hosting)
            {
                if (GUILayout.Button("Stop Hosting", GUILayout.Height(30)))
                    LeaveCurrentLobby();
            }
            else GUILayout.Label("Clients cannot leave; exit through the game.", GUI.skin.box);
            */
        }

        private void DrawUpdateOverlay()
        {
            Color overlay = new Color(0, 0, 0, 0.8f);
            GUI.color = overlay;
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), Texture2D.whiteTexture);
            GUI.color = Color.white;

            float boxWidth = 480f, boxHeight = 240f;
            float centerX = (Screen.width - boxWidth) / 2f;
            float centerY = (Screen.height - boxHeight) / 2f;

            GUIStyle title = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 28,
                fontStyle = FontStyle.Bold,
                normal = { textColor = Color.magenta }
            };

            GUI.Box(new Rect(centerX, centerY, boxWidth, boxHeight), "");
            GUI.Label(new Rect(0, centerY + 20, Screen.width, 40), "Update Required (SAM Browser)", title);

            GUI.Label(new Rect(centerX + 20, centerY + 70, boxWidth - 40, 60),
                updateMessage + "\nA new version is available.", new GUIStyle(GUI.skin.label)
                { alignment = TextAnchor.MiddleCenter, fontSize = 16, normal = { textColor = Color.white } });

            if (GUI.Button(new Rect(centerX + 140, centerY + boxHeight - 60, 200, 40), "Open GitHub"))
                Application.OpenURL("https://github.com/kitty92pm/Shift-At-Midnight-Server-broswer/releases/tag/Beta");
        }

        private void HostLobby()
        {
            SteamMatchmaking.CreateLobby(ELobbyType.k_ELobbyTypePublic, 8);
        }

        private void RefreshLobbyList()
        {
            refreshing = true;
            footerStatus = "Refreshing...";
            lobbies.Clear();
            SteamMatchmaking.RequestLobbyList();
        }

        private void OnLobbyListReceived(LobbyMatchList_t result)
        {
            lobbies.Clear();
            for (int i = 0; i < result.m_nLobbiesMatching; i++)
                lobbies.Add(SteamMatchmaking.GetLobbyByIndex(i));

            refreshing = false;
            footerStatus = $"Found {lobbies.Count} lobbies";
            KuromiNotify.Info($"Lobbies found: {lobbies.Count}");
        }

        private void OnLobbyCreated(LobbyCreated_t callback)
        {
            if (callback.m_eResult != EResult.k_EResultOK)
            {
                KuromiNotify.Error("Failed to create lobby: " + callback.m_eResult);
                return;
            }

            currentLobby = new CSteamID(callback.m_ulSteamIDLobby);
            SteamMatchmaking.SetLobbyType(currentLobby, ELobbyType.k_ELobbyTypePublic);
            SteamMatchmaking.SetLobbyData(currentLobby, "name", serverName);
            SteamMatchmaking.SetLobbyData(currentLobby, "host", SteamFriends.GetPersonaName());
            hosting = true;
            inLobby = true;
            footerStatus = "Hosting Lobby";
            KuromiNotify.Info("Lobby created: " + serverName);
        }

        private void OnLobbyEntered(LobbyEnter_t callback)
        {
            currentLobby = new CSteamID(callback.m_ulSteamIDLobby);
            inLobby = true;

            CSteamID owner = SteamMatchmaking.GetLobbyOwner(currentLobby);
            hosting = (owner == SteamUser.GetSteamID());

            footerStatus = "Connected to lobby";
            KuromiNotify.Info("Joined lobby: " + currentLobby);
        }

        private void LeaveCurrentLobby()
        {
            if (hosting)
            {
                SteamMatchmaking.LeaveLobby(currentLobby);
                KuromiNotify.Warn("Host stopped hosting and left the lobby.");
            }
            else KuromiNotify.Warn("Must leave via (Leave Game) game.");

            hosting = false;
            inLobby = false;
            lobbies.Clear();
        }

        private System.Collections.IEnumerator CheckVersion()
        {
            yield return new WaitForSeconds(3f);
            string url = "https://raw.githubusercontent.com/kitty92pm/Shift-At-Midnight-Server-broswer/main/version.txt";

            using (var req = UnityEngine.Networking.UnityWebRequest.Get(url))
            {
                req.downloadHandler = new UnityEngine.Networking.DownloadHandlerBuffer();
                var op = req.SendWebRequest();

                while (!op.isDone)
                    yield return null;

                if (req.result == UnityEngine.Networking.UnityWebRequest.Result.Success)
                {
                    string text = req.downloadHandler.text.Trim();
                    if (double.TryParse(text, System.Globalization.NumberStyles.Float,
                        System.Globalization.CultureInfo.InvariantCulture, out double onlineVersion))
                    {
                        if (onlineVersion > version)
                        {
                            updateRequired = true;
                            updateMessage = $"Update required! Current: v{version}.0 | Latest: v{onlineVersion}.0";
                            KuromiNotify.Warn(updateMessage);
                        }
                        else KuromiNotify.Info($"Version OK ({version})");
                    }
                    else KuromiNotify.Error("Invalid version file: " + text);
                }
                else KuromiNotify.Error("Web error: " + req.error);
            }
        }
    }

    public static class KuromiNotify
    {
        private class Notification { public string message; public Color color; public float time; }
        private static readonly List<Notification> active = new List<Notification>();
        private static readonly float duration = 5f;
        private static readonly Vector2 size = new Vector2(300f, 40f);

        public static void Info(string msg) => Add(msg, new Color(0.7f, 0.8f, 1f));
        public static void Warn(string msg) => Add(msg, new Color(1f, 0.8f, 0.4f));
        public static void Error(string msg) => Add(msg, new Color(1f, 0.4f, 0.4f));

        private static void Add(string msg, Color color)
        {
            active.Add(new Notification { message = msg, color = color, time = Time.time });
        }

        public static void Draw()
        {
            float y = 20f;
            GUIStyle style = new GUIStyle(GUI.skin.box)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = 14,
                wordWrap = true
            };

            for (int i = active.Count - 1; i >= 0; i--)
            {
                var n = active[i];
                float age = Time.time - n.time;
                if (age > duration) { active.RemoveAt(i); continue; }

                float alpha = Mathf.Clamp01(1f - (age / duration));
                float slide = Mathf.Lerp(Screen.width + 20f, Screen.width - size.x - 20f, Mathf.Clamp01(age / 0.3f));

                Color bg = new Color(n.color.r, n.color.g, n.color.b, alpha * 0.9f);
                GUI.color = bg;

                Rect rect = new Rect(slide, y, size.x, size.y);
                GUI.Box(rect, n.message, style);
                y += size.y + 10;
            }
            GUI.color = Color.white;
        }
    }
}
